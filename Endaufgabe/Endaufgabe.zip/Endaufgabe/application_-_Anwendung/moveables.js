"use strict";
var Endaufgabe_Football_Simulation;
(function (Endaufgabe_Football_Simulation) {
    class Moveables {
        constructor(_position, _velocity) {
            this.position = _position;
            this.velocity = _velocity;
        }
    }
    Endaufgabe_Football_Simulation.Moveables = Moveables;
})(Endaufgabe_Football_Simulation || (Endaufgabe_Football_Simulation = {}));
//# sourceMappingURL=moveables.js.map